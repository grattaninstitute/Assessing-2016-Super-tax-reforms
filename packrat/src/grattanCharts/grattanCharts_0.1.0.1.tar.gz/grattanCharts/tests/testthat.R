library(testthat)
library(grattanCharts)

test_check("grattanCharts")
