#' theme_grattan
#' @param ... arguments passed to \code{\link{theme_hugh}}.

theme_grattan <- function(...) theme_hugh(...)