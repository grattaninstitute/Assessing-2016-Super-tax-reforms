library(testthat)
test_check("rsdmx")