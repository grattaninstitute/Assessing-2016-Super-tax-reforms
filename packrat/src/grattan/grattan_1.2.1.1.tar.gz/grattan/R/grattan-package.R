#' Grattan package
#' 
#' Colours, charts, and other common quant tasks
#' 
#' @name grattan-package
#' @aliases grattan
#' @docType package
#' @title The grattan package.
#' @author \email{hugh.parsonage+grattanpackage@@grattan.edu.au}
#' @keywords package

