# grattan
[![Build Status](https://travis-ci.org/HughParsonage/grattan.svg?branch=master)](https://travis-ci.org/HughParsonage/grattan)
[![codecov.io](https://codecov.io/github/HughParsonage/grattan/coverage.svg?branch=master)](https://codecov.io/github/HughParsonage/grattan?branch=master)
[![codecov.io](https://codecov.io/github/HughParsonage/grattan/coverage.svg?branch=CRAN-2016)](https://codecov.io/github/HughParsonage/grattan?branch=CRAN-2016)

Making grattan charts easier to produce; perform common quant tasks.
